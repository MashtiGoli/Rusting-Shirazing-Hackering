import argparse
import sys
from src.db_manager import DBManager

def parse_size(size_str):
    """Parses size strings like 10G, 500M into bytes."""
    size_str = size_str.strip().upper()
    if size_str.endswith('G') or size_str.endswith('GB'):
        return int(float(size_str.replace('GB', '').replace('G', '')) * 1024 ** 3)
    elif size_str.endswith('M') or size_str.endswith('MB'):
        return int(float(size_str.replace('MB', '').replace('M', '')) * 1024 ** 2)
    elif size_str.endswith('K') or size_str.endswith('KB'):
        return int(float(size_str.replace('KB', '').replace('K', '')) * 1024)
    elif size_str.endswith('B'):
        return int(size_str.replace('B', ''))
    elif size_str == '0':
        return 0
    else:
        try:
            return int(size_str)
        except ValueError:
            print('Invalid size format. Use G, M, K (e.g. 10G, 500M, 0 for unlimited)')
            sys.exit(1)

def format_size(size_bytes):
    if size_bytes == 0:
        return 'Unlimited'
    if size_bytes >= 1024 ** 3:
        return f'{size_bytes / 1024 ** 3:.2f} GB'
    if size_bytes >= 1024 ** 2:
        return f'{size_bytes / 1024 ** 2:.2f} MB'
    if size_bytes >= 1024:
        return f'{size_bytes / 1024:.2f} KB'
    return f'{size_bytes} B'

def main():
    parser = argparse.ArgumentParser(description='MasterHttpRelayVPN User Manager')
    subparsers = parser.add_subparsers(dest='command', required=True)
    parser_add = subparsers.add_parser('add', help='Add or update a user')
    parser_add.add_argument('username', help='Username')
    parser_add.add_argument('password', help='Password')
    parser_add.add_argument('limit', help='Data limit (e.g., 10G, 500M, 0 for unlimited)')
    parser_del = subparsers.add_parser('delete', help='Delete a user')
    parser_del.add_argument('username', help='Username to delete')
    subparsers.add_parser('list', help='List all users')
    parser_reset = subparsers.add_parser('reset', help='Reset data usage for a user')
    parser_reset.add_argument('username', help='Username to reset')
    args = parser.parse_args()
    db = DBManager()
    if args.command == 'add':
        limit_bytes = parse_size(args.limit)
        db.add_user(args.username, args.password, limit_bytes)
        print(f"User '{args.username}' added/updated. Limit: {format_size(limit_bytes)}")
    elif args.command == 'delete':
        db.delete_user(args.username)
        print(f"User '{args.username}' deleted.")
    elif args.command == 'list':
        users = db.list_users()
        if not users:
            print('No users found.')
        else:
            print(f"{'Username':<20} | {'Used':<15} | {'Limit':<15} | {'Status':<10}")
            print('-' * 65)
            for user in users:
                username, used, limit, active = user
                status = 'Active' if active else 'Inactive'
                if limit > 0 and used >= limit:
                    status = 'Exceeded'
                print(f'{username:<20} | {format_size(used):<15} | {format_size(limit):<15} | {status:<10}')
    elif args.command == 'reset':
        db.reset_data_used(args.username)
        print(f"Data usage reset for user '{args.username}'.")
if __name__ == '__main__':
    main()