# MasterHttpRelayVPN - VPS Deployment & Management Guide

This guide covers everything you need to deploy, manage, and use the multi-user version of MasterHttpRelayVPN on a Linux VPS.

---

## 🚀 1. Deploying on a Linux VPS

### Step A: Transfer the Files
Upload the `vpn_linux_vps.zip` file to your Linux VPS. You can use tools like `scp`, FileZilla, or WinSCP to transfer the file. Once uploaded, SSH into your VPS.

### Step B: Install Prerequisites
Run these commands on your VPS to ensure Python 3 and `unzip` are installed:
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv unzip -y
```

### Step C: Extract and Setup
```bash
# Create a folder and move the zip inside
mkdir ~/master_vpn && mv vpn_linux_vps.zip ~/master_vpn
cd ~/master_vpn

# Extract the files
unzip vpn_linux_vps.zip

# Create a virtual environment to keep packages isolated
python3 -m venv venv
source venv/bin/activate

# Install the required packages
pip install -r requirements.txt
```

### Step D: Configuration
```bash
# Copy the example config
cp config.example.json config.json

# Edit the config file using nano
nano config.json
```
**Crucial Config Changes:**
1. Change `"listen_host": "127.0.0.1"` to `"listen_host": "0.0.0.0"`. This allows external connections to reach your VPS.
2. Put your Google Apps Script Deployment ID in `"script_id"`.
3. Set your `"auth_key"` (must match the one in your `Code.gs`).

*(Save and exit nano by pressing `Ctrl+O`, `Enter`, and `Ctrl+X`)*

### Step E: Create Your First Users
Before starting the proxy, create some users with bandwidth limits (e.g., 5GB):
```bash
python manage_users.py add myuser mypassword 5
python manage_users.py list
```

### Step F: Open Firewall Ports
If your VPS uses UFW, open the proxy ports (default 8085 for HTTP and 1080 for SOCKS5):
```bash
sudo ufw allow 8085/tcp
sudo ufw allow 1080/tcp
```

### Step G: Start the Server in the Background
To keep it running after you close the SSH terminal, you can use `tmux` or `screen`:
```bash
sudo apt install tmux -y
tmux new -s vpn

# Inside tmux, activate venv and run
source venv/bin/activate
python main.py
```
*(To detach from tmux and leave it running in the background, press `Ctrl+B`, then release and press `D`)*

---

## ⚡ 2. Speed and Performance Expectations

**Is it fast?** It will be **decent for browsing, social media, and messaging**, but **not ideal for heavy 4K streaming or massive downloads.**

**The technical reason:** The speed bottleneck is *not* your VPS; it is the Google Apps Script infrastructure. 
1. Every web request your users make is packaged, sent to Google, fetched by Google's servers, repackaged, and sent back.
2. Google Apps Script has execution time limits and a quota of **20,000 executions per day per deployment**.
3. Since multiple users will now share this server, the quota will be consumed faster.

**🔥 PRO TIP TO INCREASE SPEED & CAPACITY:**
Deploy the `Code.gs` script on **multiple different Google accounts** to get multiple Deployment IDs. You can load-balance them in your `config.json` like this:
```json
"script_ids": [
  "DEPLOYMENT_ID_1",
  "DEPLOYMENT_ID_2",
  "DEPLOYMENT_ID_3"
]
```
*(Make sure every deployment uses the exact same `auth_key`!)*

---

## 🧠 3. How to Work With It Completely (Management)

### 📊 Managing Users (The `manage_users.py` tool)
Always run this inside your `~/master_vpn` directory on the VPS (make sure the `venv` is activated):

- **Add a user with 10 GB limit:**
  `python manage_users.py add john secret123 10`
- **List all users and see how much they've used:**
  `python manage_users.py list`
- **Reset a user's traffic back to 0:**
  `python manage_users.py reset john`
- **Delete a user completely:**
  `python manage_users.py delete john`
- **Update a user's password or limit:**
  `python manage_users.py update john newpass456 20`

### 🛡️ CA Certificate (Important for HTTPS)
For the HTTP proxy to work seamlessly with HTTPS sites (and not show security warnings), users **must install the CA Certificate**. 
1. After running `main.py` for the first time, a `ca` folder will be generated on your VPS.
2. You must download `ca/ca.crt` from your VPS.
3. Send this file to your users and instruct them to install it in their device's Trusted Root Certification Authorities (Windows) or as a trusted profile (iOS/Android).

---

## 📱 4. How Users Can Connect via V2Ray Apps

Users don't need a complex custom app; they can connect to your server using popular V2Ray clients like **v2rayNG (Android)**, **Shadowrocket (iOS)**, or **v2rayN (Windows)**. 

Since your server acts as an HTTP/SOCKS5 proxy, they just need to add it as a Socks or HTTP node.

### For v2rayNG (Android)
1. Open the app and tap the **`+`** icon in the top right.
2. Choose **Type Socks** (or **Type HTTP**).
3. **Remarks:** Give it a name (e.g., "My VPN").
4. **Address:** Enter your VPS IP Address.
5. **Port:** `1080` (for SOCKS5) or `8085` (for HTTP).
6. **User:** Enter their username.
7. **Pass:** Enter their password.
8. Tap the **Checkmark (✔)** icon to save.
9. Select the profile and tap the **V** button at the bottom to connect.

### For Shadowrocket (iOS)
1. Open the app and tap the **`+`** icon in the top right to add a server.
2. Tap **Type** and select **Socks5** (or **HTTP**).
3. **Address:** Enter your VPS IP Address.
4. **Port:** `1080` (for SOCKS5) or `8085` (for HTTP).
5. **User:** Enter their username.
6. **Password:** Enter their password.
7. Tap **Done** to save, then toggle the connection on.

### For v2rayN (Windows)
1. Open v2rayN.
2. Click on **Servers** -> **Add [Socks] Server** (or **Add [Http] Server**).
3. **Address:** Enter your VPS IP Address.
4. **Port:** `1080` (for SOCKS5) or `8085` (for HTTP).
5. **User:** Enter their username.
6. **Pass:** Enter their password.
7. Click **Confirm** (OK).
8. Right-click the server in the list and select **Set as active server**, then make sure the System Proxy is set to "Set system proxy".

---

## 🔄 5. Running as a System Service (Advanced but Recommended)

Instead of using `tmux`, you can make the VPN start automatically if the VPS reboots.

1. Create a service file:
   `sudo nano /etc/systemd/system/mastervpn.service`
2. Paste this configuration (adjust paths if your username isn't `root`):
   ```ini
   [Unit]
   Description=Master VPN Proxy Server
   After=network.target

   [Service]
   User=root
   WorkingDirectory=/root/master_vpn
   Environment="PATH=/root/master_vpn/venv/bin"
   ExecStart=/root/master_vpn/venv/bin/python main.py
   Restart=always

   [Install]
   WantedBy=multi-user.target
   ```
3. Enable and start it:
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable mastervpn
   sudo systemctl start mastervpn
   sudo systemctl status mastervpn
   ```
To view the live logs anytime, use: `sudo journalctl -u mastervpn -f`
