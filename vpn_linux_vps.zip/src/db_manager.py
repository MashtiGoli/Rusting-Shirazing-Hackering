import sqlite3
import os
import threading
import logging
log = logging.getLogger('DBManager')

class DBManager:

    def __init__(self, db_path='users.db'):
        self.db_path = db_path
        self._lock = threading.Lock()
        self._init_db()

    def _init_db(self):
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('\n                    CREATE TABLE IF NOT EXISTS users (\n                        username TEXT PRIMARY KEY,\n                        password TEXT NOT NULL,\n                        data_used_bytes INTEGER DEFAULT 0,\n                        data_limit_bytes INTEGER DEFAULT 0,\n                        is_active INTEGER DEFAULT 1\n                    )\n                ')
                conn.commit()

    def get_user(self, username):
        """Returns (password, data_used_bytes, data_limit_bytes, is_active) or None."""
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT password, data_used_bytes, data_limit_bytes, is_active FROM users WHERE username = ?', (username,))
                return cursor.fetchone()

    def authenticate(self, username, password):
        """Validates credentials. Returns True if valid, False otherwise."""
        user = self.get_user(username)
        if user and user[0] == password:
            return True
        return False

    def add_user(self, username, password, limit_bytes):
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('\n                    INSERT OR REPLACE INTO users (username, password, data_limit_bytes, data_used_bytes, is_active)\n                    VALUES (?, ?, ?, COALESCE((SELECT data_used_bytes FROM users WHERE username = ?), 0), 1)\n                ', (username, password, limit_bytes, username))
                conn.commit()

    def delete_user(self, username):
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM users WHERE username = ?', (username,))
                conn.commit()

    def add_data_used(self, username, bytes_used):
        if bytes_used <= 0:
            return
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('UPDATE users SET data_used_bytes = data_used_bytes + ? WHERE username = ?', (bytes_used, username))
                conn.commit()

    def reset_data_used(self, username):
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('UPDATE users SET data_used_bytes = 0 WHERE username = ?', (username,))
                conn.commit()

    def list_users(self):
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT username, data_used_bytes, data_limit_bytes, is_active FROM users')
                return cursor.fetchall()

    def is_limit_exceeded(self, username):
        user = self.get_user(username)
        if not user:
            return True
        _, used, limit, active = user
        if not active:
            return True
        if limit > 0 and used >= limit:
            return True
        return False