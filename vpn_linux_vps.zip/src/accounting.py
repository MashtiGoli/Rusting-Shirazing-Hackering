import asyncio
import logging
from src.db_manager import DBManager
log = logging.getLogger('Accounting')

class AccountingManager:

    def __init__(self, db_manager: DBManager, flush_interval=10):
        self.db = db_manager
        self.flush_interval = flush_interval
        self._usage_buffer = {}
        self._limits = {}
        self._lock = asyncio.Lock()
        self._running = False
        self._flush_task = None

    async def start(self):
        self._running = True
        self._flush_task = asyncio.create_task(self._flush_loop())
        log.info('Accounting manager started.')

    async def stop(self):
        self._running = False
        if self._flush_task:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        await self._flush_now()
        log.info('Accounting manager stopped.')

    async def add_usage(self, username: str, bytes_used: int):
        if not username or bytes_used <= 0:
            return
        async with self._lock:
            self._usage_buffer[username] = self._usage_buffer.get(username, 0) + bytes_used
            if username in self._limits:
                used, limit, active = self._limits[username]
                self._limits[username] = (used + bytes_used, limit, active)

    def is_limit_exceeded(self, username: str) -> bool:
        """Check if user has exceeded their data limit (real-time)."""
        if not username:
            return True
        if username in self._limits:
            used, limit, active = self._limits[username]
            if not active:
                return True
            if limit > 0 and used >= limit:
                return True
            return False
        user = self.db.get_user(username)
        if not user:
            return True
        _, used, limit, active = user
        self._limits[username] = (used, limit, active)
        if not active:
            return True
        if limit > 0 and used >= limit:
            return True
        return False

    async def _flush_loop(self):
        while self._running:
            await asyncio.sleep(self.flush_interval)
            await self._flush_now()

    async def _flush_now(self):
        usage_to_flush = {}
        async with self._lock:
            if not self._usage_buffer:
                return
            usage_to_flush = self._usage_buffer
            self._usage_buffer = {}
        for username, bytes_used in usage_to_flush.items():
            try:
                self.db.add_data_used(username, bytes_used)
                user = self.db.get_user(username)
                if user:
                    _, used, limit, active = user
                    self._limits[username] = (used, limit, active)
            except Exception as e:
                log.error(f'Error flushing usage for {username}: {e}')