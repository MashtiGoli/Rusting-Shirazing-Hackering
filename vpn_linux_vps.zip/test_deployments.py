import urllib.request
import urllib.error
import json
import time

AUTH_KEY = "Mashti"

DEPLOYMENTS = [
    "AKfycbxxbX2o8Q-93_WaP-wwnXsk2IE2R4yS0XnyUfNh1ZC7v_zzkvfGhZH7PF0Kj92qee-dMQ",
    "AKfycbyPPN6vVT63Ww7_H1H6daTAoNKelgWKm1ucrBdxrlCjXoxhfOeFhThOK2zlUwNh2rg",
    "AKfycbxcVsB-qudi-8LF0KWl05zfF3mg_u-kKl3xYU57jEicEaunhbnfQhpF61TkbSgRscFZfA",
    "AKfycbwgIdg6fWOEcL4PJ-M96fC001_Ei0mttaoIgWCRpYellIQb7H-CdQeDTeW527OezgSmvA",
    "AKfycbzwF4_8OiTZoEkJHYrgbdjY2Pyu1Jy_KkskuUEiLtZLGaCWuOIlR1vv7gok-h8agYDuBg",
    "AKfycbwrwHYar_hsVS1SDuTirmj3jUWmgyVVEHh7E-JVSg8eNStT6cMWGHO7RwxLfn_rav1H",
]

def test_deployment(dep_id):
    url = f"https://script.google.com/macros/s/{dep_id}/exec"
    payload = json.dumps({"k": AUTH_KEY, "u": "https://www.google.com"}).encode()
    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    start = time.time()
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            latency = int((time.time() - start) * 1000)
            body = resp.read()
            data = json.loads(body)
            if "e" in data:
                return "FAIL", latency, f"Error: {data['e']}"
            elif "s" in data:
                return "OK", latency, f"HTTP {data['s']}"
            else:
                return "UNKNOWN", latency, str(data)[:80]
    except urllib.error.HTTPError as e:
        latency = int((time.time() - start) * 1000)
        return "FAIL", latency, f"HTTP {e.code}: {e.reason}"
    except Exception as e:
        latency = int((time.time() - start) * 1000)
        return "FAIL", latency, str(e)[:80]

print(f"\nTesting {len(DEPLOYMENTS)} deployments with auth_key='{AUTH_KEY}'")
print(f"{'#':<4} {'STATUS':<8} {'LATENCY':>8}   {'DETAIL'}")
print("-" * 70)

all_ok = True
for i, dep_id in enumerate(DEPLOYMENTS, 1):
    short_id = dep_id[:24] + "..."
    status, latency, detail = test_deployment(dep_id)
    marker = "[OK]" if status == "OK" else "[!!]"
    print(f"{marker} #{i:<3} {status:<8} {latency:>6}ms   {detail}")
    if status != "OK":
        all_ok = False

print("-" * 70)
if all_ok:
    print(f"\n[ALL OK] All {len(DEPLOYMENTS)} deployments are WORKING")
else:
    print(f"\n[WARNING] Some deployments FAILED -- check details above")
